const   express = require("express")			//////For Express.JS /////////////////
const   app = express()							//////For Express.JS /////////////////
const   expressLayouts = require('express-ejs-layouts')
const	mongoose = require("mongoose")
const   flash = require('connect-flash')
const   session = require('express-session')
const   port = 3100 							///////Port Of The LocalHost//////////


const	passport = require("passport")
const	bodyParser = require("body-parser")
const 	fs = require('fs')
const 	multer = require('multer')


const	LocalStrategy = require("passport-local")
const	passportLocalMongoose =
		require("passport-local-mongoose")
const	User = require("./models/User")
const Image = require('./models/imageSchema')


//========For Aouto Refresh=========//
const path = require("path");
const livereload = require("livereload");
const liveReloadServer = livereload.createServer();
liveReloadServer.watch(path.join(__dirname, 'public'));
 
 
const connectLivereload = require("connect-livereload");
app.use(connectLivereload());
 
liveReloadServer.server.once("connection", () => {
  setTimeout(() => {
    liveReloadServer.refresh("/");
  }, 100);
}); 
//==============================//






//Passport config
require('./config/passport')(passport)

//EJS
app.use(expressLayouts)
app.set("view engine", "ejs")    ///////Adding Templat Engine EJS /////     this will help to find index 
app.use(bodyParser.urlencoded({ extended: false })) //Bodyparser
app.use(express.static('public'))
app.use(bodyParser.json())

// Express Session
app.use(session({
	secret: "secret",
	resave: true,
	saveUninitialized: true
}));

//Passport middleweare
app.use(passport.initialize());
app.use(passport.session());


// Connect flash
app.use(flash())

// Global Variables
app.use(function(req, res, next) {
	res.locals.success_msg = req.flash('success_msg');
	res.locals.error_msg = req.flash('error_msg');
	res.locals.error = req.flash('error');
	next();
  });
  			//Put The Link Here:
mongoose.connect("XXX", { useNewUrlParser: true})
	.then(result => {
		app.listen(port, () => {
			console.log(`Example app listening on port ${port}`)
		})
	})
	.catch(err => {
		console.log(err);
	});
	



//========= Setup multer for storing uploaded files ====================//
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads')
    },
    filename: (req, file, cb) => {
        cb(null, file.fieldname + '-' + Date.now())
    }
});
 
const upload = multer({ storage: storage });
//==================================================================//





//============== POST handler for processing the uploaded file
app.post('/photos', upload.single('image'), (req, res, next) => {
 
	var obj = {
		name: req.body.name,
		desc: req.body.desc,
		img: {
			data: fs.readFileSync(path.join(__dirname + '/uploads/' + req.file.filename)),
			contentType: 'image/png'
		}
	}
	Image.create(obj, (err, item) => {
		if (err) {
			console.log(err);
		}
		else {
			// item.save();
			res.redirect('/photos');
		}
	});
  });
  //==============================//




  const { ensureAuthenticated, forwardAuthenticated } = require('./config/auth');


// to go Photos & to GET all images form MongosDB 
 //     (the GET request handler that provides the HTML UI)
//  app.get('/photos',  ensureAuthenticated, (req, res) => {
// 	Image.find({}, (err, items) => {
// 		if (err) {
// 			console.log(err);
// 			res.status(500).send('An error occurred', err);
// 		}
// 		else {
// 			res.render('photos', { items: items,  name: req.user.name})
//             //console.log(items)
// 		}
// 	});
//   });
//   //==============================//

  //======Get All Photos===========//
app.get('/photos', ensureAuthenticated, (req, res) => {
    Image.find()      // Result will be array of objects inside MongoDB (result = all articles)
    .then((items) => {   res.render('photos', {items: items, name: req.user.name })   }) //   arrArticle: result   send this array to index
    .catch((err) => {console.log(err)})

})
//==============================//


 







//=====================
// ROUTES
app.use('/', require('./routes/index'))
app.use('/users', require('./routes/users'))

//=====================



