var mongoose = require('mongoose');
const Schema = mongoose.Schema;
 
var imageSchema = new Schema({
    name: String,
    desc: String, //description
    img:
    {
        data: Buffer, // Buffer refers to the particular memory location in memory
        contentType: String // type of the image ... png or jpeg....
    }
});
 
//Image is a model which has a schema imageSchema
const Image = new mongoose.model('Image', imageSchema);

// export the model        (to send the schema to app.js)
module.exports = Image; 