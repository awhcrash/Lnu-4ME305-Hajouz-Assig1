const express = require('express')
const app = express() 

const router = express.Router()
const { ensureAuthenticated, forwardAuthenticated } = require('../config/auth');

const Image = require('../models/imageSchema')


// Welcome Page
router.get('/', forwardAuthenticated, (req, res) => res.render('welcome' ));

// Dashboard
router.get('/dashboard', ensureAuthenticated, (req, res) => {
  res.render('dashboard', { name: req.user.name })
  
}
)

//========== go to Photos & Find all images ============//
router.get('/views/photos.ejs', ensureAuthenticated, (req, res) => {
    Image.find()      // Result will be array of objects inside MongoDB (result = all articles)
    .then((items) => { res.render('photos', { name: req.user.name, items: items }) }  )
    .catch((err) => {console.log(err)})
  }
  )

  // Upload
router.get('/views/upload.ejs', ensureAuthenticated, (req, res) => {
    
    res.render('upload', { name: req.user.name})
  }
  )

// to go Photos after uploading an image
// router.get('/photos', ensureAuthenticated, (req, res) => {
    
//     res.render('photos', { name: req.user.name})
//   }
//   )




//  // to go Photos & to GET all images form MongosDB 
//  //     (the GET request handler that provides the HTML UI)
// app.get('/photos',  ensureAuthenticated, (req, res) => {
// 	Image.find({}, (err, items) => {
// 		if (err) {
// 			console.log(err);
// 			res.status(500).send('An error occurred', err);
// 		}
// 		else {
// 			res.render('photos', { items: items,  name: req.user.name})
//             //console.log(items)
// 		}
// 	});
//   });
//   //==============================//






module.exports = router;